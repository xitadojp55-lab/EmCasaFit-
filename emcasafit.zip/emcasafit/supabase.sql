-- ===== EmCasaFit: rode no SQL Editor do Supabase =====
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text,
  peso_atual float,
  peso_meta float,
  objetivo text,
  equipamentos text[],
  dias_treino int,
  criado_em date default current_date -- inicio do plano de 21 dias
);
create table if not exists pesos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  peso float not null,
  data date default current_date,
  foto_url text
);
create table if not exists treinos_concluidos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  treino_id text not null,
  data date default current_date
);
-- Seguranca: cada usuaria so ve os seus dados
alter table profiles enable row level security;
alter table pesos enable row level security;
alter table treinos_concluidos enable row level security;
create policy "perfil proprio" on profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "pesos proprios" on pesos for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "treinos proprios" on treinos_concluidos for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
-- Bucket publico para fotos antes/depois
insert into storage.buckets (id, name, public) values ('fotos','fotos',true) on conflict do nothing;
create policy "upload fotos" on storage.objects for insert to authenticated with check (bucket_id='fotos');
create policy "ler fotos" on storage.objects for select using (bucket_id='fotos');

-- Assinaturas: a usuaria so LE; quem escreve e o servidor (service_role) -> paywall nao e burlavel
create table if not exists assinaturas (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text default 'ativa',
  metodo text,
  valido_ate date not null
);
alter table assinaturas enable row level security;
create policy "ler propria assinatura" on assinaturas for select using (auth.uid() = user_id);
