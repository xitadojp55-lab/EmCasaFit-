/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: { extend: { colors: { brand: { DEFAULT: '#7C3AED', dark: '#6D28D9', soft: '#EDE9FE' } } } },
  plugins: [],
};
