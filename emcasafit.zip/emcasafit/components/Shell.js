'use client';
// Layout comum com barra de navegacao inferior (mobile-first)
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, TrendingDown, Utensils } from 'lucide-react';
const ABAS = [{ h: '/dashboard', i: Home, t: 'Início' }, { h: '/evolucao', i: TrendingDown, t: 'Evolução' }, { h: '/alimentacao', i: Utensils, t: 'Comida' }];
export default function Shell({ children }) {
  const path = usePathname();
  return (
    <div className="pb-24">
      {children}
      <nav className="fixed bottom-0 left-1/2 flex w-full max-w-md -translate-x-1/2 border-t bg-white">
        {ABAS.map(({ h, i: Icon, t }) => (
          <Link key={h} href={h} className={`flex flex-1 flex-col items-center gap-1 py-3 text-xs ${path === h ? 'font-semibold text-brand' : 'text-gray-400'}`}>
            <Icon size={22} />{t}
          </Link>
        ))}
      </nav>
    </div>
  );
}
