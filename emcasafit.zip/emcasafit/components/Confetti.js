'use client';
// Confetti simples em CSS (sem bibliotecas)
const CORES = ['#7C3AED', '#A78BFA', '#F59E0B', '#10B981', '#EC4899'];
export default function Confetti() {
  return Array.from({ length: 60 }).map((_, i) => (
    <span key={i} className="confete" style={{ left: `${Math.random() * 100}%`, background: CORES[i % 5], animationDelay: `${Math.random() * 0.8}s` }} />
  ));
}
