// Middleware EmCasaFit: protege rotas e aplica o paywall NO SERVIDOR
// (a usuaria nao consegue contornar mexendo no navegador).
import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

const PUBLICAS = ['/login'];

export async function middleware(req: NextRequest) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  // Sem Supabase configurado = modo demo (localStorage); o useGuard cuida das regras no cliente
  if (!url || !key) return NextResponse.next();

  let res = NextResponse.next({ request: req });
  // Cliente Supabase que le/atualiza a sessao nos cookies
  const supabase = createServerClient(url, key, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll: (lista) => {
        lista.forEach(({ name, value }) => req.cookies.set(name, value));
        res = NextResponse.next({ request: req });
        lista.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
      },
    },
  });

  // getUser() valida o token no servidor do Supabase (nao confia so no cookie)
  const { data: { user } } = await supabase.auth.getUser();
  const path = req.nextUrl.pathname;

  // Redireciona preservando os cookies de sessao renovados
  const irPara = (destino: string) => {
    const u = req.nextUrl.clone(); u.pathname = destino; u.search = '';
    const r = NextResponse.redirect(u);
    res.cookies.getAll().forEach((c) => r.cookies.set(c));
    return r;
  };

  // 1) Sem login -> so pode ver /login
  if (!user) return PUBLICAS.includes(path) ? res : irPara('/login');
  if (path === '/login') return irPara('/dashboard');

  // 2) Sem perfil -> onboarding obrigatorio
  const { data: perfil } = await supabase.from('profiles').select('criado_em').eq('id', user.id).maybeSingle();
  if (!perfil) return path === '/onboarding' ? res : irPara('/onboarding');
  if (path === '/onboarding') return irPara('/dashboard');

  // 3) Paywall: dia >= 3 sem assinatura ativa -> /pagamento
  const hoje = new Date().toISOString().slice(0, 10);
  const dia = Math.floor((new Date(hoje).getTime() - new Date(perfil.criado_em).getTime()) / 864e5) + 1;
  const { data: ass } = await supabase.from('assinaturas').select('valido_ate').eq('user_id', user.id).maybeSingle();
  const pago = !!ass && ass.valido_ate >= hoje;
  if (dia >= 3 && !pago && path !== '/pagamento') return irPara('/pagamento');
  if (pago && path === '/pagamento') return irPara('/dashboard');

  return res;
}

// Nao roda em arquivos estaticos, /api (valida a sessao por conta propria) nem /auth/callback
export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|api|auth|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)'],
};
