# EmCasaFit — publicar na Vercel em 3 passos

> Teste local: `npm install && npm run dev` (sem variáveis = modo demo).

## Passo 1 — Supabase (banco + login Google)
1. Crie um projeto em supabase.com. No **SQL Editor**, rode `supabase.sql` (se já tinha rodado a versão antiga, rode só `supabase-migracao.sql`).
2. Em **Project Settings > API**, copie `Project URL`, `anon key` e `service_role key`.
3. Google: em console.cloud.google.com crie um **OAuth Client ID** (tipo *Web*) e, em *Authorized redirect URIs*, coloque `https://SEU-PROJETO.supabase.co/auth/v1/callback`. Cole o Client ID e o Secret em **Supabase > Authentication > Providers > Google** e ative.

## Passo 2 — Vercel
1. Envie a pasta para um repositório no GitHub.
2. Em vercel.com: **Add New > Project**, importe o repositório.
3. Em *Environment Variables* cadastre as 4 chaves de `.env.example` (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `PAGAMENTO_SIMULADO`) e clique **Deploy**.

## Passo 3 — Liberar o domínio no Supabase
Com a URL da Vercel (ex: `https://emcasafit.vercel.app`), vá em **Supabase > Authentication > URL Configuration**:
- **Site URL:** `https://emcasafit.vercel.app`
- **Redirect URLs:** `https://emcasafit.vercel.app/auth/callback` (e `http://localhost:3000/auth/callback` para testes)

Pronto: teste o login com Google. Para testar o paywall, no Supabase altere `criado_em` do seu perfil para 3 dias atrás: você será levada a `/pagamento`.

## Como funciona o paywall
`middleware.ts` roda no servidor em cada página: sem login → `/login`; sem perfil → `/onboarding`; dia ≥ 3 sem linha válida em `assinaturas` → `/pagamento`. Só o servidor grava em `assinaturas` (service_role), então o paywall não pode ser burlado pelo navegador.

## Antes de cobrar de verdade
Defina `PAGAMENTO_SIMULADO=false` e ative a assinatura a partir do webhook do M-Pesa/e-Mola/PayPal (veja `app/api/pagamento/confirmar/route.js`). Enquanto estiver `true`, qualquer usuária logada ativa de graça.
