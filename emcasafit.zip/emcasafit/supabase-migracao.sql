-- Rode SOMENTE se voce ja tinha executado a versao anterior do supabase.sql
alter table profiles drop column if exists pago;
create table if not exists assinaturas (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text default 'ativa', metodo text, valido_ate date not null
);
alter table assinaturas enable row level security;
create policy "ler propria assinatura" on assinaturas for select using (auth.uid() = user_id);
