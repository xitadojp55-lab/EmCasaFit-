'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Lock, Smartphone, CreditCard } from 'lucide-react';
import { useGuard, setPago } from '@/lib/store';
const METODOS = [{ id: 'mpesa', n: 'M-Pesa', i: Smartphone }, { id: 'emola', n: 'e-Mola', i: Smartphone }, { id: 'paypal', n: 'PayPal', i: CreditCard }];
export default function Pagamento() {
  const perfil = useGuard(); const r = useRouter(); const [m, setM] = useState('mpesa'); const [carregando, setC] = useState(false);
  // Pagamento SIMULADO: troque por API real (M-Pesa Mozambique, e-Mola, PayPal)
  async function pagar() { setC(true); try { await new Promise((x) => setTimeout(x, 1800)); await setPago(m); r.replace('/dashboard'); r.refresh(); } catch (e) { alert(e.message); setC(false); } }
  if (!perfil) return <div className="p-6 text-gray-400">Carregando…</div>;
  return (
    <main className="flex min-h-screen flex-col justify-center bg-white px-6">
      <div className="mx-auto mb-4 rounded-full bg-brand-soft p-4 text-brand"><Lock size={32} /></div>
      <h1 className="text-center text-2xl font-extrabold">Seu teste acabou!</h1>
      <p className="mb-6 mt-2 text-center text-gray-500">Continue por <b className="text-brand">750MT/mês</b> e mantenha o seu progresso.</p>
      {METODOS.map(({ id, n, i: Icon }) => (
        <button key={id} onClick={() => setM(id)} className={`mb-3 flex items-center gap-3 rounded-xl border-2 p-4 font-semibold ${m === id ? 'border-brand bg-brand-soft text-brand' : 'border-gray-200'}`}><Icon size={20} /> {n}</button>
      ))}
      <button onClick={pagar} disabled={carregando} className="mt-3 rounded-2xl bg-brand py-4 text-lg font-extrabold text-white disabled:opacity-60">
        {carregando ? 'A processar…' : 'Ativar agora - 750MT'}
      </button>
      <p className="mt-3 text-center text-xs text-gray-400">Pagamento simulado para demonstração.</p>
    </main>
  );
}
