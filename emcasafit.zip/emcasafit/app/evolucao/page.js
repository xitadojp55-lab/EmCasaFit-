'use client';
import { useEffect, useState } from 'react';
import { Plus, X } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import Shell from '@/components/Shell';
import { useGuard, getPesos, addPeso } from '@/lib/store';
export default function Evolucao() {
  const perfil = useGuard(); const [pesos, setPesos] = useState([]); const [modal, setModal] = useState(false);
  const [peso, setPeso] = useState(''); const [foto, setFoto] = useState(null);
  const carregar = () => getPesos().then(setPesos);
  useEffect(() => { if (perfil) carregar(); }, [perfil]);
  async function salvar() { if (!peso) return; await addPeso(peso, foto); setModal(false); setPeso(''); setFoto(null); carregar(); }
  if (!perfil) return <div className="p-6 text-gray-400">Carregando…</div>;
  const fotos = pesos.filter((p) => p.foto_url); const antes = fotos[0], depois = fotos[fotos.length - 1];
  const perdido = pesos.length > 1 ? (pesos[0].peso - pesos[pesos.length - 1].peso).toFixed(1) : '0.0';
  return (
    <Shell>
      <div className="space-y-4 p-4">
        <h1 className="text-xl font-bold">Sua evolução</h1>
        <p className="text-sm text-gray-500">Perdeu <b className="text-brand">{perdido} kg</b> · Meta: {perfil.peso_meta} kg</p>
        <section className="rounded-2xl bg-white p-4 shadow-sm">
          {pesos.length < 2 ? <p className="py-10 text-center text-sm text-gray-400">Adicione pelo menos 2 registos para ver o gráfico.</p> : (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={pesos}><CartesianGrid strokeDasharray="3 3" stroke="#eee" /><XAxis dataKey="data" tickFormatter={(d) => d.slice(5)} fontSize={11} />
                <YAxis domain={['dataMin-1', 'dataMax+1']} fontSize={11} width={32} /><Tooltip />
                <ReferenceLine y={perfil.peso_meta} stroke="#10B981" strokeDasharray="4 4" />
                <Line type="monotone" dataKey="peso" stroke="#7C3AED" strokeWidth={3} /></LineChart>
            </ResponsiveContainer>)}
        </section>
        <section className="rounded-2xl bg-white p-4 shadow-sm">
          <p className="mb-3 font-bold">Antes / Depois</p>
          {antes && depois && antes !== depois ? (
            <div className="grid grid-cols-2 gap-3">{[['Antes', antes], ['Depois', depois]].map(([l, f]) => (
              <div key={l}><img src={f.foto_url} alt={l} className="aspect-[3/4] w-full rounded-xl object-cover" /><p className="mt-1 text-center text-sm">{l} · {f.peso}kg</p></div>))}</div>
          ) : <p className="text-sm text-gray-400">Adicione fotos em dois dias diferentes para comparar.</p>}
        </section>
        <button onClick={() => setModal(true)} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-brand py-4 font-bold text-white"><Plus /> Adicionar peso de hoje</button>
      </div>
      {modal && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/50" onClick={() => setModal(false)}>
          <div onClick={(e) => e.stopPropagation()} className="mx-auto w-full max-w-md rounded-t-3xl bg-white p-6">
            <div className="mb-4 flex justify-between"><h2 className="text-lg font-bold">Peso de hoje</h2><button onClick={() => setModal(false)}><X /></button></div>
            <input type="number" inputMode="decimal" placeholder="Peso em kg" value={peso} onChange={(e) => setPeso(e.target.value)} className="mb-3 w-full rounded-xl border px-4 py-3 text-lg" />
            <input type="file" accept="image/*" onChange={(e) => setFoto(e.target.files[0])} className="mb-4 w-full text-sm" />
            <button onClick={salvar} className="w-full rounded-xl bg-brand py-3 font-bold text-white">Salvar</button>
          </div>
        </div>)}
    </Shell>
  );
}
