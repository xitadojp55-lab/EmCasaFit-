'use client';
import { useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Timer, Check } from 'lucide-react';
import Confetti from '@/components/Confetti';
import { useGuard, concluirTreino } from '@/lib/store';
import { TREINOS } from '@/lib/data';
export default function Treino() {
  const perfil = useGuard(); const { id } = useParams(); const r = useRouter();
  const t = TREINOS[id] || TREINOS.t1;
  const [feitos, setFeitos] = useState([]); const [seg, setSeg] = useState(30); const [rodando, setRod] = useState(false); const [fim, setFim] = useState(false);
  const iv = useRef();
  // Timer de 30s
  useEffect(() => {
    if (!rodando) return;
    iv.current = setInterval(() => setSeg((s) => { if (s <= 1) { clearInterval(iv.current); setRod(false); return 30; } return s - 1; }), 1000);
    return () => clearInterval(iv.current);
  }, [rodando]);
  async function concluir() {
    await concluirTreino(id); setFim(true); setTimeout(() => r.push('/dashboard'), 2800);
  }
  if (!perfil) return <div className="p-6 text-gray-400">Carregando…</div>;
  return (
    <main className="pb-8">
      {fim && <><Confetti /><div className="fixed inset-0 z-50 flex items-center justify-center bg-brand/90 text-center text-white"><div><p className="text-5xl">🎉</p><p className="mt-2 text-2xl font-extrabold">Parabéns!</p><p>Treino concluído</p></div></div></>}
      <button onClick={() => r.back()} className="p-4"><ArrowLeft /></button>
      <h1 className="px-4 text-xl font-bold">{t.titulo}</h1>
      {/* Video placeholder do YouTube */}
      <div className="m-4 aspect-video overflow-hidden rounded-2xl bg-black"><iframe className="h-full w-full" src={t.video} title="Treino" allowFullScreen /></div>
      <div className="mx-4 mb-4 flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm">
        <div className="flex items-center gap-2 text-2xl font-bold text-brand"><Timer /> 0:{String(seg).padStart(2, '0')}</div>
        <button onClick={() => { setSeg(30); setRod(!rodando); }} className="rounded-xl bg-brand px-5 py-2 font-semibold text-white">{rodando ? 'Parar' : 'Iniciar 30s'}</button>
      </div>
      <ul className="mx-4 space-y-2">
        {t.exercicios.map((e, i) => (
          <li key={e}><button onClick={() => setFeitos(feitos.includes(i) ? feitos.filter((x) => x !== i) : [...feitos, i])} className="flex w-full items-center gap-3 rounded-xl bg-white p-4 text-left shadow-sm">
            <span className={`flex h-6 w-6 items-center justify-center rounded-md border-2 ${feitos.includes(i) ? 'border-brand bg-brand text-white' : 'border-gray-300'}`}>{feitos.includes(i) && <Check size={16} />}</span>
            <span className={feitos.includes(i) ? 'text-gray-400 line-through' : ''}>{e}</span></button></li>
        ))}
      </ul>
      <div className="px-4 pt-6"><button onClick={concluir} className="w-full rounded-2xl bg-brand py-5 text-lg font-extrabold text-white">CONCLUÍ TREINO</button></div>
    </main>
  );
}
