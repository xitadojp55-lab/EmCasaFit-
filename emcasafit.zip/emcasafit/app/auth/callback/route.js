import { NextResponse } from 'next/server';
import { servidor } from '@/lib/supabase-server';
// O Google volta para ca com ?code=...; trocamos por uma sessao (cookies) e entramos no app
export async function GET(request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  if (code) {
    const { error } = await servidor().auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(`${origin}/dashboard`);
  }
  return NextResponse.redirect(`${origin}/login?erro=auth`);
}
