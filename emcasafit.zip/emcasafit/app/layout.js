import './globals.css';
export const metadata = { title: 'EmCasaFit', description: 'Emagreça em casa com 15min por dia' };
export const viewport = { width: 'device-width', initialScale: 1, themeColor: '#7C3AED' };
export default function RootLayout({ children }) {
  return (<html lang="pt"><body><div className="mx-auto min-h-screen max-w-md bg-gray-50 shadow-sm">{children}</div></body></html>);
}
