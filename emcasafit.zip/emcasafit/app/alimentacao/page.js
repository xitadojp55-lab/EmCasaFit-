'use client';
import { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import Shell from '@/components/Shell';
import { useGuard, getTroca, setTroca } from '@/lib/store';
import { REFEICOES } from '@/lib/data';
export default function Alimentacao() {
  const perfil = useGuard(); const [idx, setIdx] = useState({ Café: 0, Almoço: 0, Lanche: 0, Jantar: 0 });
  useEffect(() => { const t = getTroca(); setIdx({ Café: t % 3, Almoço: t % 3, Lanche: t % 3, Jantar: t % 3 }); }, []);
  // Troca de refeicao: avanca para a proxima opcao
  const trocar = (nome) => setIdx((s) => ({ ...s, [nome]: (s[nome] + 1) % 3 }));
  if (!perfil) return <div className="p-6 text-gray-400">Carregando…</div>;
  const total = Object.entries(REFEICOES).reduce((a, [n, l]) => a + l[idx[n]].k, 0);
  return (
    <Shell>
      <div className="space-y-3 p-4">
        <h1 className="text-xl font-bold">Cardápio de hoje</h1>
        <p className="text-sm text-gray-500">Total: <b className="text-brand">{total} kcal</b></p>
        {Object.entries(REFEICOES).map(([nome, opcoes]) => (
          <section key={nome} className="flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm">
            <div><p className="text-sm font-semibold text-brand">{nome}</p><p className="font-medium">{opcoes[idx[nome]].n}</p><p className="text-sm text-gray-400">{opcoes[idx[nome]].k} kcal</p></div>
            <button onClick={() => trocar(nome)} className="flex items-center gap-1 rounded-xl bg-brand-soft px-3 py-2 text-xs font-semibold text-brand"><RefreshCw size={14} /> Trocar refeição</button>
          </section>
        ))}
      </div>
    </Shell>
  );
}
