import { redirect } from 'next/navigation';
export default function Home() { redirect('/dashboard'); } // o guard decide o resto
