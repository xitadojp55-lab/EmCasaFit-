import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { servidor } from '@/lib/supabase-server';
// Ativa 30 dias de assinatura. Usa a service_role key, que NUNCA vai para o navegador.
// ATENCAO: com PAGAMENTO_SIMULADO=true qualquer usuaria logada ativa de graca (so para demo).
// Em producao: defina PAGAMENTO_SIMULADO=false e chame esta logica a partir do webhook
// do M-Pesa/e-Mola/PayPal, depois de verificar a assinatura do provedor.
export async function POST(req) {
  if (process.env.PAGAMENTO_SIMULADO !== 'true')
    return NextResponse.json({ erro: 'Pagamento real ainda nao configurado' }, { status: 403 });
  const { data: { user } } = await servidor().auth.getUser();
  if (!user) return NextResponse.json({ erro: 'Nao autenticada' }, { status: 401 });
  const { metodo } = await req.json().catch(() => ({}));
  const ate = new Date(); ate.setDate(ate.getDate() + 30);
  const admin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  const { error } = await admin.from('assinaturas').upsert({
    user_id: user.id, status: 'ativa', metodo: metodo || 'simulado', valido_ate: ate.toISOString().slice(0, 10),
  });
  if (error) return NextResponse.json({ erro: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
