'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Play, Droplets, Plus, Eye, LogOut } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import Shell from '@/components/Shell';
import { useGuard, diaAtual, getPesos, getAgua, setAgua, sair, avancarDia, sb } from '@/lib/store';
import { treinoDoDia, TREINOS } from '@/lib/data';
export default function Dashboard() {
  const perfil = useGuard(); const [agua, setA] = useState(0); const [pesos, setPesos] = useState([]);
  useEffect(() => { setA(getAgua()); getPesos().then((p) => setPesos(p.slice(-7))); }, [perfil]);
  if (!perfil) return <div className="p-6 text-gray-400">Carregando…</div>;
  const dia = diaAtual(perfil); const tid = treinoDoDia(dia);
  const addAgua = () => { const n = Math.min(8, agua + 1); setA(n); setAgua(n); };
  return (
    <Shell>
      <header className="bg-brand px-5 pb-6 pt-8 text-white">
        <div className="flex items-start justify-between">
          <h1 className="text-xl font-bold">Olá, {perfil.nome}!</h1>
          <button onClick={sair} aria-label="Sair"><LogOut size={20} /></button>
        </div>
        <p className="mt-1 text-sm opacity-90">Dia {dia} de 21</p>
        <div className="mt-3 h-2 rounded-full bg-white/30"><div className="h-2 rounded-full bg-white" style={{ width: `${(dia / 21) * 100}%` }} /></div>
      </header>
      <div className="space-y-4 p-4">
        <section className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-brand">TREINO DE HOJE</p>
          <p className="my-2 text-lg font-bold">15min {TREINOS[tid].titulo}</p>
          <Link href={`/treino/${tid}`} className="flex items-center justify-center gap-2 rounded-xl bg-brand py-3 font-bold text-white"><Play size={18} /> PLAY</Link>
        </section>
        <section className="flex items-center justify-between rounded-2xl bg-white p-5 shadow-sm">
          <div><p className="text-xs font-semibold text-brand">CARDÁPIO</p><p className="text-lg font-bold">1.400 kcal hoje</p></div>
          <Link href="/alimentacao" className="flex items-center gap-1 rounded-xl bg-brand-soft px-4 py-2 font-semibold text-brand"><Eye size={16} /> VER</Link>
        </section>
        <section className="flex items-center justify-between rounded-2xl bg-white p-5 shadow-sm">
          <div className="flex items-center gap-3"><Droplets className="text-sky-500" /><div><p className="text-xs font-semibold text-brand">ÁGUA</p><p className="text-lg font-bold">{agua}/8 copos</p></div></div>
          <button onClick={addAgua} aria-label="Adicionar copo" className="rounded-full bg-brand p-3 text-white"><Plus size={20} /></button>
        </section>
        <section className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="mb-2 font-bold">Peso nos últimos 7 registos</p>
          {pesos.length < 2 ? <p className="text-sm text-gray-400">Registe o seu peso em Evolução para ver o gráfico.</p> : (
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={pesos}><XAxis dataKey="data" hide /><YAxis domain={['dataMin-1', 'dataMax+1']} hide /><Tooltip />
                <Line type="monotone" dataKey="peso" stroke="#7C3AED" strokeWidth={3} dot /></LineChart>
            </ResponsiveContainer>)}
        </section>
        {!sb && <button onClick={avancarDia} className="w-full text-xs text-gray-400 underline">Demo: simular +1 dia (testar paywall no dia 3)</button>}
      </div>
    </Shell>
  );
}
