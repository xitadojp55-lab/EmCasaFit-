'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { saveProfile, getUser } from '@/lib/store';
const OBJ = ['Perder Barriga', 'Perder Peso', 'Definir Corpo'];
const EQ = ['Nada', 'Garrafas de água', 'Elástico', 'Halteres'];
export default function Onboarding() {
  const r = useRouter(); const [step, setStep] = useState(1);
  const [d, setD] = useState({ objetivo: '', equipamentos: [], peso_atual: '', peso_meta: '', dias_treino: 0 });
  // Multi-select: "Nada" limpa os outros
  const toggleEq = (e) => setD((s) => ({ ...s, equipamentos: e === 'Nada' ? ['Nada'] : s.equipamentos.includes(e) ? s.equipamentos.filter((x) => x !== e) : [...s.equipamentos.filter((x) => x !== 'Nada'), e] }));
  const ok = [d.objetivo, d.equipamentos.length, d.peso_atual && d.peso_meta, d.dias_treino][step - 1];
  async function finalizar() {
    const u = await getUser();
    await saveProfile({ nome: (u?.email || 'Amiga').split('@')[0], ...d, peso_atual: +d.peso_atual, peso_meta: +d.peso_meta });
    r.push('/dashboard');
  }
  const Op = ({ ativo, onClick, children }) => (
    <button onClick={onClick} className={`mb-3 w-full rounded-xl border-2 p-4 text-left font-semibold ${ativo ? 'border-brand bg-brand-soft text-brand' : 'border-gray-200 bg-white'}`}>{children}</button>
  );
  return (
    <main className="min-h-screen bg-white px-6 py-8">
      <div className="mb-8 h-2 rounded-full bg-gray-200"><div className="h-2 rounded-full bg-brand transition-all" style={{ width: `${step * 25}%` }} /></div>
      {step === 1 && <><h2 className="mb-5 text-2xl font-bold">Qual é o seu objetivo?</h2>{OBJ.map((o) => <Op key={o} ativo={d.objetivo === o} onClick={() => setD({ ...d, objetivo: o })}>{o}</Op>)}</>}
      {step === 2 && <><h2 className="mb-5 text-2xl font-bold">O que tem em casa?</h2>{EQ.map((e) => <Op key={e} ativo={d.equipamentos.includes(e)} onClick={() => toggleEq(e)}>{e}</Op>)}</>}
      {step === 3 && <><h2 className="mb-5 text-2xl font-bold">Seu peso</h2>
        {[['peso_atual', 'Peso atual (kg)'], ['peso_meta', 'Peso meta (kg)']].map(([k, l]) => (
          <label key={k} className="mb-4 block text-sm text-gray-500">{l}<input type="number" inputMode="decimal" value={d[k]} onChange={(e) => setD({ ...d, [k]: e.target.value })} className="mt-1 w-full rounded-xl border px-4 py-3 text-lg text-gray-900" /></label>
        ))}</>}
      {step === 4 && <><h2 className="mb-5 text-2xl font-bold">Dias de treino por semana</h2>{[3, 4, 5].map((n) => <Op key={n} ativo={d.dias_treino === n} onClick={() => setD({ ...d, dias_treino: n })}>{n} dias</Op>)}</>}
      <div className="mt-6 flex gap-3">
        {step > 1 && <button onClick={() => setStep(step - 1)} className="rounded-xl border px-5 py-4 font-semibold">Voltar</button>}
        <button disabled={!ok} onClick={() => (step < 4 ? setStep(step + 1) : finalizar())} className="flex-1 rounded-xl bg-brand py-4 font-bold text-white disabled:opacity-40">
          {step < 4 ? 'Continuar' : 'Gerar meu plano de 21 dias'}
        </button>
      </div>
    </main>
  );
}
