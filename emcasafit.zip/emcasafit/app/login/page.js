'use client';
import { useState } from 'react';
import { Dumbbell, Mail } from 'lucide-react';
import { entrar, sb } from '@/lib/store';
export default function Login() {
  const [email, setEmail] = useState(''); const [campo, setCampo] = useState(false); const [msg, setMsg] = useState('');
  async function porEmail() {
    if (!campo) return setCampo(true);
    const r = await entrar('email', email);
    if (sb && !r?.error) setMsg('Enviámos um link para o seu email.');
  }
  return (
    <main className="flex min-h-screen flex-col justify-center bg-white px-6">
      <div className="mb-8 flex items-center gap-2 text-2xl font-extrabold text-brand"><Dumbbell /> EmCasaFit</div>
      <h1 className="mb-3 text-3xl font-extrabold leading-tight">Perca até 4kg em 30 dias com 15min em casa</h1>
      <p className="mb-8 text-gray-500">Treinos curtos, cardápio simples e acompanhamento diário.</p>
      <button onClick={() => entrar('google')} className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl border py-3 font-semibold">
        <span className="font-bold text-blue-500">G</span> Entrar com Google
      </button>
      {campo && <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="seu@email.com" className="mb-3 w-full rounded-xl border px-4 py-3" />}
      <button onClick={porEmail} className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand py-3 font-semibold text-white">
        <Mail size={18} /> Entrar com Email
      </button>
      {msg && <p className="mt-3 text-sm text-brand">{msg}</p>}
      {!sb && <p className="mt-6 text-center text-xs text-gray-400">Modo demo: dados guardados neste aparelho.</p>}
    </main>
  );
}
